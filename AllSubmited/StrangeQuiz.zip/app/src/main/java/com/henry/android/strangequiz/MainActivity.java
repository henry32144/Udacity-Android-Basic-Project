package com.henry.android.strangequiz;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private EditText Question1;
    private CheckBox Question2_1, Question2_2, Question2_3, Question2_4;
    private RadioGroup Question3, Question4, Question5;
    private TextView q1, q2, q3, q4, q5;
    private boolean[] answer = new boolean[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Question1 = (EditText) findViewById(R.id.answer_q1);
        Question2_1 = (CheckBox) findViewById(R.id.q2_checkbox_1);
        Question2_2 = (CheckBox) findViewById(R.id.q2_checkbox_2);
        Question2_3 = (CheckBox) findViewById(R.id.q2_checkbox_3);
        Question2_4 = (CheckBox) findViewById(R.id.q2_checkbox_4);
        Question3 = (RadioGroup) findViewById(R.id.q3_radioGroup);
        Question4 = (RadioGroup) findViewById(R.id.q4_radioGroup);
        Question5 = (RadioGroup) findViewById(R.id.q5_radioGroup);
        q1 = (TextView) findViewById(R.id.quiz_q1);
        q2 = (TextView) findViewById(R.id.quiz_q2);
        q3 = (TextView) findViewById(R.id.quiz_q3);
        q4 = (TextView) findViewById(R.id.quiz_q4);
        q5 = (TextView) findViewById(R.id.quiz_q5);
    }

    /**
     * This method reset answer array to false
     */
    private void resetAnswer() {
        Arrays.fill(answer, Boolean.FALSE);
    }

    /**
     * This method call check answer function and send result to pop up window
     */
    public void submit(View view) {
        resetAnswer();
        checkAnswer();
        int points = calculatePoints();
        String message = createSummary(points);
        setAlertDialog(message);
    }

    /**
     * This method clean points and reset question area
     */
    public void restart(View view) {
        Question1.setText("");
        Question2_1.setChecked(false);
        Question2_2.setChecked(false);
        Question2_3.setChecked(false);
        Question2_4.setChecked(false);
        Question3.clearCheck();
        Question4.clearCheck();
        Question5.clearCheck();
        resetQuestionColor();
        resetAnswer();
    }


    /**
     * This method check user's answer
     */
    private void checkAnswer() {
        //-----------Question 1----------
        if (Question1.getText().toString().trim().length() > 0) {
            if (Integer.parseInt(Question1.getText().toString()) == 60) {
                answer[0] = true;
                markQuestion(q1, true);
            } else {
                markQuestion(q1, false);
            }
        } else {
            markQuestion(q1, false);
        }
        //-----------Question 2----------
        if (Question2_1.isChecked() == false) {
            boolean selection2 = Question2_2.isChecked();
            boolean selection3 = Question2_3.isChecked();
            boolean selection4 = Question2_4.isChecked();
            if (selection2 == true && selection3 == true && selection4 == true) {
                answer[1] = true;
                markQuestion(q2, true);
            }
            else {
                markQuestion(q2, false);
            }
        } else {
            markQuestion(q2, false);
        }
        //-----------Question 3----------
        if (Question3.getCheckedRadioButtonId() == R.id.q3_selection_1) {
            answer[2] = true;
            markQuestion(q3, true);
        } else {
            markQuestion(q3, false);
        }
        //-----------Question 4----------
        if (Question4.getCheckedRadioButtonId() == R.id.q4_selection_n) {
            answer[3] = true;
            markQuestion(q4, true);
        } else {
            markQuestion(q4, false);
        }
        //-----------Question 5----------
        if (Question5.getCheckedRadioButtonId() == R.id.q5_selection_n) {
            answer[4] = true;
            markQuestion(q5, true);
        } else {
            markQuestion(q5, false);
        }
    }

    /**
     * This method calculate total points
     */
    private int calculatePoints() {
        int points = 0;
        for (int i = 0; i < answer.length; i++) {
            if (answer[i] == true) {
                points += 20;
            }
        }
        return points;
    }

    /**
     * This method create Summary message
     *
     * @param score is the total score
     */
    private String createSummary(int score) {
        String message = getString(R.string.get_score, score) + "\n";
        if (score == 100) {
            message += getString(R.string.all_correct) + "\n" + "\n";
        }
        message += getString(R.string.answer_1) + "\n";
        message += getString(R.string.answer_2) + "\n";
        message += getString(R.string.answer_3) + "\n";
        message += getString(R.string.answer_4) + "\n";
        message += getString(R.string.answer_5) + "\n";
        return message;
    }

    private void resetQuestionColor() {
        q1.setTextColor(Color.rgb(0, 0, 0));
        q2.setTextColor(Color.rgb(0, 0, 0));
        q3.setTextColor(Color.rgb(0, 0, 0));
        q4.setTextColor(Color.rgb(0, 0, 0));
        q5.setTextColor(Color.rgb(0, 0, 0));
    }

    /**
     * This method change  question color
     *
     * @param view      is the question TextView which is checking by checkAnswer Function
     * @param isCorrect is the answer correct or not
     */
    private void markQuestion(TextView view, boolean isCorrect) {
        if (isCorrect == true) {
            view.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.correct));
        } else {
            view.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.error));
        }
    }

    /**
     * This method pop the message window
     *
     * @param message is the message about final score and all answers
     */
    private void setAlertDialog(String message) {
        new AlertDialog.Builder(MainActivity.this)
                .setTitle(R.string.scores)
                .setMessage(message)
                .show();
    }
}
