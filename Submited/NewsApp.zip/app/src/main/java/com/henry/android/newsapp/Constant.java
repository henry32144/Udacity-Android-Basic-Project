package com.henry.android.newsapp;

/**
 * Created by Henry on 2017/8/28.
 */

public class Constant {
    public class JSONKey {
        public static final String response = "response";
        public static final String results = "results";
        public static final String webTitle = "webTitle";
        public static final String sectionName = "sectionName";
        public static final String webPublicationDate = "webPublicationDate";
        public static final String webUrl = "webUrl";
    }
}
