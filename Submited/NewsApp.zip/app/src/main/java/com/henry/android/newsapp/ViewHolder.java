package com.henry.android.newsapp;

import android.widget.TextView;

/**
 * Created by Henry on 2017/8/28.
 */

public class ViewHolder{
    TextView newsTitleText;
    TextView newsTagText;
    TextView newsDateText;
}

