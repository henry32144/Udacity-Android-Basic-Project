package com.henry.android.musicstructure;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class DatabaseActivity extends MainActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        //Set Button onclick event except itself
        ImageButton mainButton = (ImageButton) findViewById(R.id.main_button);

        mainButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(DatabaseActivity.this, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
            }
        });

        ImageButton accountButton = (ImageButton) findViewById(R.id.account_button);

        accountButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent accountIntent = new Intent(DatabaseActivity.this, AccountActivity.class);
                accountIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(accountIntent);
            }
        });

        //song example
        TextView songEx1 = (TextView) findViewById(R.id.song_ex1);

        songEx1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent playitent = new Intent(DatabaseActivity.this, PlayingActivity.class);
                playitent.putExtra("name", view.getTag().toString());
                startActivity(playitent);
            }
        });

        TextView songEx2 = (TextView) findViewById(R.id.song_ex2);

        songEx2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent playitent = new Intent(DatabaseActivity.this, PlayingActivity.class);
                playitent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                playitent.putExtra("name", view.getTag().toString());
                startActivity(playitent);
            }
        });
    }
}
