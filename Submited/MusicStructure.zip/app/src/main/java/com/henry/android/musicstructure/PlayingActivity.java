package com.henry.android.musicstructure;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class PlayingActivity extends AppCompatActivity {

    public static String playingsong = "none";
    public static boolean isPlaying = false;
    public TextView currentPlaying;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing);

        //Set Button onclick event except itself

        ImageButton mainButton = (ImageButton) findViewById(R.id.main_button);

        mainButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(PlayingActivity.this, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
            }
        });


        ImageButton databaseButton = (ImageButton) findViewById(R.id.database_button);

        databaseButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent databaseIntent = new Intent(PlayingActivity.this, DatabaseActivity.class);
                databaseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(databaseIntent);
            }
        });

        ImageButton accountButton = (ImageButton) findViewById(R.id.account_button);

        accountButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent accountIntent = new Intent(PlayingActivity.this, AccountActivity.class);
                accountIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(accountIntent);
            }
        });

        //set player button
        ImageButton playButton = (ImageButton) findViewById(R.id.play_button);

        playButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                playSong(playingsong);
            }
        });

        final ImageButton nextButton = (ImageButton) findViewById(R.id.next_button);

        nextButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                nextSong();
            }
        });

        currentPlaying = (TextView) findViewById(R.id.current_playing_song);
        currentPlaying.setText(playingsong);

        final ImageButton previousButton = (ImageButton) findViewById(R.id.previous_button);

        previousButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                previousSong();
            }
        });

        //get song click event
        Intent intent = getIntent();

        if(intent.hasExtra("name")) {
            playingsong = intent.getStringExtra("name");
            playSong(playingsong);
        }

    }

    //player button events
    public void playSong(String song) {
        if(playingsong.equals("none")) {
            playingsong = "song 1";
            currentPlaying.setText(playingsong);
            switchPlayIcon();
            isPlaying = true;
        }
        else if(!song.equals("none")){
            switchPlayIcon();
            isPlaying = true;
            currentPlaying.setText(song);
        }
        else if(isPlaying){
            switchPlayIcon();
        }
    }

    public void switchPlayIcon() {
        ImageButton playButton = (ImageButton) findViewById(R.id.play_button);
        if(isPlaying) {
            isPlaying = false;
            playButton.setImageResource(R.drawable.ic_play_arrow_black_48dp);
        }
        else {
            isPlaying = true;
            playButton.setImageResource(R.drawable.ic_pause_black_48dp);
        }
    }

    public void nextSong() {
        //This hard code is for demo, in formal situation should use list
        if(currentPlaying.getText().equals("song 1")) {
            playingsong = "song 2";
            currentPlaying.setText(playingsong);
        }
        else {
            showToast("Oh , this is the last song");
        }
    }

    public void previousSong() {
        if(currentPlaying.getText().equals("song 2")) {
            playingsong = "song 1";
            currentPlaying.setText(playingsong);
        }
        else {
            showToast("Oh , this is the first song");
        }
    }

    public void showToast(String message) {
        Toast toast = Toast.makeText(PlayingActivity.this, message, Toast.LENGTH_SHORT);
        toast.show();
    }


}
