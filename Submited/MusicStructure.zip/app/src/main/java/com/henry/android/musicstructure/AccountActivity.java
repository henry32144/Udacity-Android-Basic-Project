package com.henry.android.musicstructure;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class AccountActivity extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        //Set Button onclick event except itself
        ImageButton databaseButton = (ImageButton) findViewById(R.id.database_button);

        databaseButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent databaseIntent = new Intent(AccountActivity.this, DatabaseActivity.class);
                databaseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(databaseIntent);
            }
        });

        ImageButton mainButton = (ImageButton) findViewById(R.id.main_button);

        mainButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(AccountActivity.this, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainIntent);
            }
        });
    }
}
