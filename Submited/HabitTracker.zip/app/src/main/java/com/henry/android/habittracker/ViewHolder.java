package com.henry.android.habittracker;

import android.widget.TextView;

/**
 * Created by Henry on 2017/9/7.
 */

public class ViewHolder {
    TextView habitNameText;
    TextView habitDayText;
    TextView habitTimeText;
}
