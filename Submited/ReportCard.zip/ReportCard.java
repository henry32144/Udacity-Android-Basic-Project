package com.example.android.miwok;

import java.util.ArrayList;

/**
 * Created by Henry on 2017/7/31.
 */

public class ReportCard {
    private String mSubjectName;

    private ArrayList<Integer> grade = new ArrayList<Integer>();

    //constructer
    public ReportCard(String iSubjectName , ArrayList<Integer> grade) {
        mSubjectName = iSubjectName;
        this.grade = grade;
    }

    //get one grade
    public String getGrade(int index) {
        if(index >= 0 && index <= grade.size()) {
            return "Index: " + index + "  grade: " + grade.get(index);
        }
        else return "Out of range";
    }

    //get all grade
    public Object[] getAll() {
        return grade.toArray();
    }

    //get subject name
    public String getSubjectName() {
        return mSubjectName;
    }

    //get all grade
    public String toString() {
        String result = "Subject: " + mSubjectName + "\n";
        for (int i = 0; i < grade.size(); i++) {
            result += "Index: " + i + "\t Grade: " + grade.get(i) + "\n";
        }
        return result;
    }

    //get grade size
    public int getSize() {
        return grade.size();
    }

    //add grade
    public void addGrade(int point) throws Exception{
        if(point >= 0 && point <= 100) {
            grade.add(point);
        }
        else {
            throw new Exception("Not in the range");
        }
    }

    //change name
    public void changeSubjectName(String name) {
        mSubjectName = name;
    }

    //clear all grade
    public void clearAll() {
        grade.clear();
    }
}
