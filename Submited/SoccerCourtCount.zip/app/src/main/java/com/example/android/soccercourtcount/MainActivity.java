package com.example.android.soccercourtcount;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    final int getPoint = 1;
    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int yellowCardNumberA = 0;
    int redCardNumberA = 0;
    int yellowCardNumberB = 0;
    int redCardNumberB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * When button get click add point to the team
     */
    public void getPointA(View view) {
        scoreTeamA += getPoint;
        displayForTeamA(scoreTeamA);
    }

    public void getPointB(View view) {
        scoreTeamB += getPoint;
        displayForTeamB(scoreTeamB);
    }

    /**
     * Record misconduct and display it
     */

    public void misconductCount(View view) {
        int thisButtonID = view.getId();
        if (thisButtonID == R.id.yellow_card_a) {
            yellowCardNumberA += 1;
            countMisconduct(thisButtonID, yellowCardNumberA);
        }
        if (thisButtonID == R.id.yellow_card_b) {
            yellowCardNumberB += 1;
            countMisconduct(thisButtonID, yellowCardNumberB);
        }
        if (thisButtonID == R.id.red_card_a) {
            redCardNumberA += 1;
            countMisconduct(thisButtonID, redCardNumberA);
        }
        if (thisButtonID == R.id.red_card_b) {
            redCardNumberB += 1;
            countMisconduct(thisButtonID, redCardNumberB);
        }
    }

    public void countMisconduct(int Id, int score) {
        Button this_button = (Button) findViewById(Id);
        this_button.setText(String.valueOf(score));
    }


    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Reset
     */

    public void resetMiscount() {
        countMisconduct(R.id.yellow_card_a, yellowCardNumberA);
        countMisconduct(R.id.yellow_card_b, yellowCardNumberB);
        countMisconduct(R.id.red_card_a, redCardNumberA);
        countMisconduct(R.id.red_card_b, redCardNumberB);
    }

    public void resetScore(View view) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        yellowCardNumberA = 0;
        redCardNumberA = 0;
        yellowCardNumberB = 0;
        redCardNumberB = 0;
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
        resetMiscount();
    }
}
