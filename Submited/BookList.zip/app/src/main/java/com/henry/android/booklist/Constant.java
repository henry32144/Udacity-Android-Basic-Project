package com.henry.android.booklist;

/**
 * Created by Henry on 2017/8/25.
 */

public class Constant {
    public class JSONKey {
        public static final String volumnInfo = "volumeInfo";
        public static final String items = "items";
        public static final String title = "title";
        public static final String authors = "authors";
        public static final String publisher = "publisher";
        public static final String infoLink = "infoLink";
    }
}
